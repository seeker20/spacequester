<?php

$fieldtyp[0][0] = "SternFeld"; #typ bezeichnung
$fieldtyp[0][1] = false; #indb
$fieldtyp[0][2] = "S"; #abk�rzung
$fieldtyp[0][3] = true; #anfleigen
$fieldtyp[0][4] = true; #Handeln
$fieldtyp[0][5] = true; #Angreifen
$fieldtyp[0][6] = true; #Besetzen

$fieldtyp[1][0] = "Planet"; #typ bezeichnung
$fieldtyp[1][1] = true; #indb
$fieldtyp[1][2] = "P"; #abk�rzung
$fieldtyp[1][3] = true; #anfleigen
$fieldtyp[1][4] = true; #Handeln
$fieldtyp[1][5] = true; #Angreifen
$fieldtyp[1][6] = true; #Besetzen

$fieldtyp[2][0] = "Raumstation"; #typ bezeichnung
$fieldtyp[2][1] = true; #indb
$fieldtyp[2][2] = "R"; #abk�rzung
$fieldtyp[2][3] = true; #anfleigen
$fieldtyp[2][4] = true; #Handeln
$fieldtyp[2][5] = true; #Angreifen
$fieldtyp[2][6] = true; #Besetzen
