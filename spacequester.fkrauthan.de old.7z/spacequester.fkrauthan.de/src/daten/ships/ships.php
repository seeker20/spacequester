<?php
#S�ldner start schiff
$ships[0][0] 	= "Mini J�ger";
$ships[0][1] 	= 100;
$ships[0][2] 	= 100;
$ships[0][3]	= "ship1.png";
$ships[0][4]	= "Der Kleien J�ger eigent sich nur f�r sehr Schwache gegener da er kaum standard bewaffnugn aht und euserst lahm ist.";
$ships[0][5]	= 100;

#H�ndler start schiff
$ships[1][0] 	= "Mini Frachter";
$ships[1][1] 	= 100;
$ships[1][2] 	= 100;
$ships[1][3]	= "ship1.png";
$ships[1][4]  = "In den Mini Frachter passen nur wenig wahren um ein erfolgreicher H�ndler zu werden sollten sie sich eine bessern Zulegen.";
$ships[1][5]	= 100;

#Soldat start schiff
$ships[2][0] 	= "Mini Star Fighter";
$ships[2][1] 	= 100;
$ships[2][2] 	= 100;
$ships[2][3]	= "ship1.png";
$ships[2][4]  = "Der Mini StarFrighter ist in der Standard ausgabe noch etwas zu wenig gut bewaffnet aber wenn er mal aufgemoptz ist kanne er ein starker verbpndeter sein.";
$ships[2][5]	= 100;

#pirat start schiff
$ships[3][0] 	= "Mini TransFighter";
$ships[3][1] 	= 100;
$ships[3][2] 	= 100;
$ships[3][3]	= "ship1.png";
$ships[3][4]  = "der Mini TransFighter ist eine mischung aus Mini J�ger und Mini Frachter. Er h�lt zwar ncihts aus hat aber eine kelein bewaffnung un etwas Frachtraum.";
$ships[3][5]	= 100;
?>