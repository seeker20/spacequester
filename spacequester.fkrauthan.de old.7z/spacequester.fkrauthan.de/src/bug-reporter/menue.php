<h3>Navigation</h3>
<div id="navcontainer">
<ul id="navlist">
	<li><a href='main.php?target=home'>&Uuml;bersicht</a></li>
	<li><a href='main.php?target=newbug'>Bug melden</a></li>
	<li><a href='main.php?target=oldbugs'>Bugs anzeigen</a></li>
	<li><a href='main.php?target=suche'>Suchen</a></li>
</ul>
</div>