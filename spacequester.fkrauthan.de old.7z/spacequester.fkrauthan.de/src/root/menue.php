<h3>Navigation</h3>
<div id="navcontainer">
<ul id="navlist">
	<li><a href='main.php?target=home'>Home</a></li>
	<li><a href='main.php?target=news'>News</a></li>
	<li><a href='main.php?target=screen'>Screenshots</a></li>
	<li><a href='main.php?target=registrierung'>Registriern</a></li>
	<li><a href='main.php?target=login'>Login</a></li>
	<li><a href='main.php?target=pwf'>Passwort vergessen</a></li>
	<li><a href='main.php?target=team'>Das Team</a></li>
	<li><a href='main.php?target=stats'>Statistik</a></li>
	<li><a href='main.php?target=impressum'>Impressum</a></li>
</ul>
</div>