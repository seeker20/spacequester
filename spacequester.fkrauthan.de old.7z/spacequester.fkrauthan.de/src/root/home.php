<h2>Home</h2>
<h4>Wilkommen</h4>
<div id='wmessage'>
	Wilkommen auf unsere Seite. Am besten du meldest dich gleich an und startest
	in ein faszienirednes erlebnis in den unednlichen Weiten der Galaxy. Was du 
	dazu brauchst ist nur dein Browser der css unterst&#252;tzt. Wenn du alle Futeres
	benutzen willst und ein Grafisch aufw&#228;ndiges erlebnis haben m&#246;chtest ben&#246;tigst du
	JavaScript und Cookies und eine schnelle internetleitung. Solltest du ber keine
	schnelle internetleitung verfgen oder du nicht so viel daten runtreladen m&#246;chtest
	solltest du beim login auf Sparmodus schalten. Wir empfehlen den Firefox. Viel Spa&#223; in den
	unednlichen weiten die wir geschaffen haben wnscht ihnen ihr SpaceQuester Team.
</div>
<br>
<h4>Story</h4>
<div id='story'>
	Wir schreiben das Jahr 2065. Die Erde ist schon lange ncihtmerh der einzige ort wor 
	menschen leben. Inziwschen leben sie auch auf dem Mars und auf sogut wie jedem Planeten. 
	Es gibt keinen Ort in der Galaxie der nicht mehr von Menschen besiedelt ist. Doch diese 
	ausbreitung hat auch gefahren. Weltraum Piraten k&#246;nnen ungehindert Hadneslschiffe angreifen. 
	Und durch die entfernungen k&#246;nnen auch Infos ber Piraten erst nach Tagen an alle 
	vermittelt werden troz des rie&#223;igen und schnellen Info netzes. Doch die Polizei r&#252;stet auf 
	und es gibt inzwischen merh Patrolien auf den gekenzeichneten Handelsrouten. Doch eines 
	Tages entkommt einer der schlimmsten Piraten bei einem Transport von Einer Verhandlung zu 
	einem Hochsicherheits Planeten. Nach krzester Zeit wusste sogut wie jeder das er enkommen 
	war. Es war gespr&#228;chstoff &#252;beral. Der Spieler hat nun die wahl zwsichen
</div>
<br>
<h4>Spieler Aufgabe</h4>
<div id='playerrul'>
	Der Spieler hat nun die wahl zwischen mehreren Berufen. H&#228;ndler, S&#246;ldner, Polizei und Pirat. 
	Jede Klasse hat eigene Schiffe und Werte. Sie k&#246;nnen dan den Weltraum erkunden, Freunde 
	finden sich in Allianzen zusammen tun und auftr&#228;ge erf&#252;llen die einen berall erwarten.
</div>