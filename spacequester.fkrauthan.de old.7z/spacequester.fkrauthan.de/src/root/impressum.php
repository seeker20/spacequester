<h2>Impressum</h2>
<p>Florian Krauthan</p>
<p>Fliederstr. 37</p>
<p>82110 Germering</p>
<p>Tel.: 089/8411437</p>
<p> <?php echo no_spammail("webmaster@fkrauthan.de"); ?> </p>