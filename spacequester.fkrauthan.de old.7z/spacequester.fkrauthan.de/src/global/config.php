<?php

$email_pro_user = 10;
$user_max_regist = 10;

?>